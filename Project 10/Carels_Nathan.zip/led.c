//------------------------------------------------------------------------------
//Description:  This file contains all code related to the initilization and
//              function of leds
//
//By:           Nathan Carels
//Date:         2/6/2021
//Build:        Built with IAR Embedded Workbench Version: V7.20.1.997 (7.20.1)
//------------------------------------------------------------------------------


#include "macros.h"
#include  "msp430.h"
